### 1.导入架包

~~~xml
<!--EsClient架包 -->
<dependency>
	<groupId>org.elasticsearch.client</groupId>
	<artifactId>transport</artifactId>
	<version>5.6.10</version>
</dependency>
<!--log4j架包 -->
<dependency>
    <groupId>org.apache.logging.log4j</groupId>
    <artifactId>log4j-core</artifactId>
    <version>${log4j2.version}</version>
</dependency>
<dependency>
    <groupId>org.apache.logging.log4j</groupId>
    <artifactId>log4j-api</artifactId>
    <version>${log4j2.version}</version>
</dependency>

~~~

### 2.连接对象-Client

	Client是一个类，通过这个类可以实现对ES集群的各种操作：Index, Get, Delete , Search，以及对ES集群的管理任务。Client的构造需要基于TransportClient

#### 2-1.TransportClient

	TransportClient可以远程连接ES集群，通过一个传输模块，但是它不真正的连接到集群，只是获取集群的一个或多个初始传输地址，在每次请求动作时，才真正连接到ES集群。 

#### 2-2.Settings

Settings类主要是在启动Client之前，配置一些属性参数，主要配置集群名称cluster.name，还有其他参数：

client.transport.sniff  是否为传输client添加嗅探功能

client.transport.ignore_cluster_name 设为true，忽略连接节点的集群名称验证

client.transport.ping_timeout 设置ping节点时的时间限，默认5s

client.transport.nodes_sampler_interval 设置sample/ping nodes listed 间隔时间，默认5s

~~~java
//通过Settings类设置属性参数
Settings settings = Settings.settingsBuilder().put("cluster.name","index-name").build();

//启动Client
Client client = TransportClient.builder().settings(settings).build().
    addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName("192.168.xxx.xxx"),9300));

//如果不需要设置参数，直接如下
/*Client client = TransportClient.builder().build().
				addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName("192.168.xxx.xxx"),9300));*/

//关闭Clinet
client.close();
~~~

#### 2-3 RestClient

~~~
参考：
https://blog.csdn.net/u011781521/article/details/77853571?locationNum=9&fps=1
https://blog.csdn.net/chenjiale0102/article/details/78770293
https://blog.csdn.net/u013294278/article/details/78903476
~~~



###3.document(增、删、改、批量) 

#### 3-1.产生Json的方式

1. 手动拼接一个JSON字符串 
2. 使用Map 
3. 使用第三方库，比如Jackson 
4. 使用内置的XContentFactory.jsonBuilder() 

每种类型都会转换为byte[]，因此如果对象已经是这种形式，可以直接使用，jsonBuilder是一个高度优化了的JSON产生器，它直接构造byte[] 

#### 3-2.index, get, delete, update 

- prepareIndex方法：索引数据到ElasticSearch 
- prepareGet方法:获取信息 
- prepareDelete方法：删除信息 
- update方法：更新信息 
  - upsert：在使用update方法时 
    - 针对文档不存在的情况时，做出index数据的操作,update无效 
    - 如果文档存在，那么index数据操作无效，update有效 

~~~java
public static void main(String[] args) throws IOException, InterruptedException, ExecutionException {
		//通过Settings类设置属性参数  
		Settings settings = Settings.settingsBuilder().put("cluster.name","myApp").build(); 		  
		//启动Client  
		Client client = null;
		try {
			client = TransportClient.builder().settings(settings).build().  
			        addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName("101.200.124.27"),9300));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}  
		//执行操作
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		XContentBuilder jsonBuilder = XContentFactory.jsonBuilder()
				.startObject()
				.field("user","yuchen")
				.field("interest","reading book")
				.field("insert_time",df.format(new Date()))
				.endObject();
		//1.prepareIndex方法：索引数据到ElasticSearch
		IndexResponse response = client.prepareIndex("index-test","weibo","4")
			.setSource(jsonBuilder)
			.get();
		
		String _index = response.getIndex();
		String _type = response.getType();
		String _id = response.getId();
		long _version = response.getVersion();
		boolean created = response.isCreated();
		System.out.println(_index+" "+_type+" "+_id+" "+_version+" "+created);
		
		//2.prepareGet方法:获取信息
		GetResponse getResponse = client.prepareGet("index-test","weibo","1").get();
		System.out.println(getResponse.getSourceAsString());
		
		//3.prepareDelete方法：删除信息
		DeleteResponse deleteResponse = client.prepareDelete("index-test","weibo","4").get();
		System.out.println(deleteResponse.isFound());
		
		//4.update方法：更新信息
		UpdateRequest updateRequest = new UpdateRequest();
		updateRequest.index("index-test"); 
		updateRequest.type("weibo");
		updateRequest.id("1");
		updateRequest.doc(XContentFactory.jsonBuilder().startObject().field("interest","music").endObject());
		UpdateResponse updateResponse = client.update(updateRequest).get();
		System.out.println(updateResponse.isCreated());
		//update方法： 可以为已有的文档添加新的字段
		UpdateResponse updateResponse2 = client.prepareUpdate("index-test", "weibo", "1")
			.setDoc(XContentFactory.jsonBuilder()
				.startObject()
				.field("interest2","reading")
				.endObject()).get();
		System.out.println(updateResponse2.isCreated());
    
		//4.1 upsert：在使用update方法时
         //a:针对文档不存在的情况时，做出index数据的操作,update无效；
		//b:如果文档存在，那么index数据操作无效，update有效；
		//先构建一个IndexRequest
		IndexRequest indexRequest = new IndexRequest("index-test","weibo","14");
		indexRequest.source(XContentFactory.jsonBuilder()
				.startObject()
				.field("user","yuchen2")
				.field("interest","eating")
				.field("insert_time",df.format(new Date()))
				.endObject());
		//再构建一个UpdateRequest，并用IndexRequest关联
		UpdateRequest updateRequest3 = new UpdateRequest("index-test","weibo","14");
		updateRequest3.doc(XContentFactory.jsonBuilder()
				.startObject()
				.field("interest2","love")
				.endObject()
				).upsert(indexRequest);
		client.update(updateRequest3).get();
		
		if(client != null){
			client.close();  
		}
	}
~~~

#### 3-3.批量操作

Multi Get Api 和 Bulk Api可进行批量的增删改查 

批量获取代码：

~~~java
//1. Muti-get Api
		//可以指定单个id,也在index,type下指定一个id-list；也可以指定别的index/type
		MultiGetResponse multiGetResponse = client.prepareMultiGet()
				.add("index-test","weibo","1")//指定单个id
				.add("index-test","weibo","11","13","14")//指定一个id-list
				.add("index-other","news","1","3").get();//指定别的index/type
		for(MultiGetItemResponse item:multiGetResponse){
			GetResponse response = item.getResponse();
			System.out.println(response.getSourceAsString());

~~~

批量增加代码：

~~~java
//2.Bulk Api:可以进行批量index和批量删除操作
		//2.1批量增加
		BulkRequestBuilder bulkRequest = client.prepareBulk();
		bulkRequest.add(client.prepareIndex("index-test", "weibo", "20")
	        .setSource(XContentFactory.jsonBuilder()
	                .startObject()
	                    .field("user", "yuchen20")
	                    .field("postDate", new Date())
	                    .field("message", "trying out Elasticsearch")
	                .endObject()
	              )
          );
		bulkRequest.add(client.prepareIndex("index-test", "weibo", "21")
		        .setSource(XContentFactory.jsonBuilder()
		                .startObject()
		                    .field("user", "yuchen21")
		                    .field("postDate", new Date())
		                    .field("message", "trying out Elasticsearch")
		                .endObject()
		              )
	          );
		
		BulkResponse bulkResponse = bulkRequest.get();
		if(bulkResponse.hasFailures()){
			//...
		}
~~~

批量删除代码

~~~java
//2.2批量删除
		BulkRequestBuilder bulkRequest = client.prepareBulk();
		bulkRequest.add(client.prepareDelete("index-test", "weibo", "20")
          );
		bulkRequest.add(client.prepareDelete("index-test", "weibo", "21")
	          );
		
		BulkResponse bulkResponse = bulkRequest.get();
		if(bulkResponse.hasFailures()){
			System.out.println("bulk error:"+bulkResponse.buildFailureMessage());
		}
~~~

批量更新代码

~~~java
//2.3批量更新
		BulkRequestBuilder bulkRequest = client.prepareBulk();
		bulkRequest.add(client.prepareUpdate("index-test", "weibo", "11").setDoc(XContentFactory
				.jsonBuilder().startObject()
				.field("country","China")//新添加字段
				.endObject()
				)
          );
		bulkRequest.add(client.prepareUpdate("index-test", "weibo", "13").setDoc(XContentFactory
				.jsonBuilder().startObject()
				.field("user","yuchen13")//更新字段
				.endObject()
				)
	          );
		
		BulkResponse bulkResponse = bulkRequest.get();
		if(bulkResponse.hasFailures()){
			System.out.println("bulk error:"+bulkResponse.buildFailureMessage());
		}
~~~

### 4.批量请求提交-BulkProcessor

~~~java
//BulkProcessor
BulkProcessor bulkProcessor = BulkProcessor.builder(client, new BulkProcessor.Listener() {
    @Override
    public void beforeBulk(long arg0, BulkRequest arg1) {
        //批量执行前做的事情
        System.out.println("bulk api action starting...");
    }
    @Override
    public void afterBulk(long arg0, BulkRequest arg1, Throwable arg2) {
        System.out.println("exception:bukl api action ending...:"+arg2.getMessage());
    }
    @Override
    public void afterBulk(long arg0, BulkRequest arg1, BulkResponse arg2) {
        //正常执行完毕后...
        System.out.println("normal:bukl api action ending...");
    }
})
    //设置多种条件，对批量操作进行限制，达到限制中的任何一种触发请求的批量提交
    .setBulkActions(1000)//设置批量操作一次性执行的action个数，根据请求个数批量提交
    //.setBulkSize(new ByteSizeValue(1,ByteSizeUnit.KB))//设置批量提交请求的大小允许的最大值
    //.setFlushInterval(TimeValue.timeValueMillis(100))//根据时间周期批量提交请求
    //.setConcurrentRequests(1)//设置允许并发请求的数量
    //设置请求失败时的补偿措施，重复请求3次
    //.setBackoffPolicy(BackoffPolicy.exponentialBackoff(TimeValue.timeValueMillis(100), 3))
    .build();
for(int i =0;i<100000;i++){
    bulkProcessor.add(new IndexRequest("index-test","weibo2",""+i).source(
        XContentFactory
        .jsonBuilder()
        .startObject()
        .field("name","yuchen"+i)
        .field("interest","love"+i)
        .endObject()));
}

bulkProcessor.awaitClose(5, TimeUnit.MINUTES);//释放bulkProcessor资源
System.out.println("load succeed!");

默认的参数：
sets bulkActions to 1000
sets bulkSize to 5mb
does not set flushInterval
sets concurrentRequests to 1
sets backoffPolicy to an exponential backoff with 8 retries and a start delay of 50ms. The total wait time is roughly 5.1 seconds.
~~~

### 5.方法封装

#### 1.查看集群信息 

~~~java
public static void getClusterInfo() {
        List<DiscoveryNode> nodes = client.connectedNodes();
        for (DiscoveryNode node : nodes) {
            System.out.println("HostId:"+node.getHostAddress()+" hostName:"+node.getHostName()+" Address:"+node.getAddress());
        }
    }

~~~

#### 2.新建索引一

~~~java
/**
     * 功能描述：新建索引
     * @param indexName 索引名
     */
public static void createIndex(String indexName) {
    try {
        if (indexExist(indexName)) {
            System.out.println("The index " + indexName + " already exits!");
        } else {
            CreateIndexResponse cIndexResponse = client.admin().indices()
                .create(new CreateIndexRequest(indexName))
                .actionGet();
            if (cIndexResponse.isAcknowledged()) {
                System.out.println("create index successfully！");
            } else {
                System.out.println("Fail to create index!");
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
}

~~~

#### 3.新建索引二

~~~java
/**
     * 功能描述：新建索引
     * @param index 索引名
     * @param type 类型
     */
    public static void createIndex(String index, String type) {
        try {
			client.prepareIndex(index, type).setSource().get();
		} catch (Exception e) {
			System.out.println("Fail to create index!");
			e.printStackTrace();
		}
    }
~~~

#### 4.删除索引 

~~~java
/**
     * 功能描述：删除索引
     * @param index 索引名
     */
    public static void deleteIndex(String index) {
        try {
			if (indexExist(index)) {
			    DeleteIndexResponse dResponse = client.admin().indices().prepareDelete(index)
			            .execute().actionGet();
			    if (!dResponse.isAcknowledged()) {
			        logger.info("failed to delete index " + index + "!");
			    }else {
			    	logger.info("delete index " + index + " successfully!");
			    }
			} else {
			    logger.error("the index " + index + " not exists!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
~~~

#### 5.验证索引是否存在 

~~~java
/**
     * 功能描述：验证索引是否存在
     * @param index 索引名
     */
    public static boolean indexExist(String index) {
        IndicesExistsRequest inExistsRequest = new IndicesExistsRequest(index);
        IndicesExistsResponse inExistsResponse = client.admin().indices()
                .exists(inExistsRequest).actionGet();
        return inExistsResponse.isExists();
    }
~~~

#### 6.插入数据 

~~~
/**
     * 功能描述：插入数据
     * @param index 索引名
     * @param type 类型
     * @param json 数据
     */
    @SuppressWarnings("deprecation")
	public static void insertData(String index, String type, String json) {
        IndexResponse response = client.prepareIndex(index, type)
                .setSource(json)
                .get();
        System.out.println(response.getVersion());
    }

~~~

#### 7.获取所有的索引 

~~~
/**
     * 功能描述：获取所有的索引
     */
    public static void getAllIndex(){
        ClusterStateResponse response = client.admin().cluster().prepareState().execute().actionGet();
        //获取所有索引
        String[] indexs=response.getState().getMetaData().getConcreteAllIndices();
        System.out.println("Index总数为: " + indexs.length);
        for (String index : indexs) {
           System.out.println("获取的Index: " + index);
        }
     }

~~~

#### 8.通过prepareIndex增加文档，参数为json字符串 

~~~java
/**
     * 通过prepareIndex增加文档，参数为json字符串
     * @param index 索引名
     * @param type  类型
     * @param _id   数据id
     * @param json  数据
     */
    @SuppressWarnings("deprecation")
	public static void insertData(String index, String type, String _id, String json) {
        IndexResponse indexResponse = client.prepareIndex(index, type).setId(_id)
                .setSource(json)
                .get();
        System.out.println(indexResponse.getVersion());
		logger.info("数据插入ES成功！");
    }

~~~

#### 9.更新数据 

~~~java
/**
     * 功能描述：更新数据
     * @param index 索引名
     * @param type  类型
     * @param _id   数据id
     * @param json  数据
     */
    @SuppressWarnings("deprecation")
	public static void updateData(String index, String type, String _id, String json){
        try {
            UpdateRequest updateRequest = new UpdateRequest(index, type, _id).doc(json);
//            client.prepareUpdate(index, type, _id).setDoc(json).get();
            client.update(updateRequest).get();
        } catch (Exception e) {
            logger.error("update data failed." + e.getMessage());
        }
    }

~~~

#### 10.删除指定数据

~~~java
/**
     * 功能描述：删除指定数据
     * @param index 索引名
     * @param type  类型
     * @param _id   数据id
     */
    public static void deleteData(String index, String type, String _id) {
        try {
			DeleteResponse response = client.prepareDelete(index, type, _id).get();
			System.out.println(response.isFragment());
			logger.info("删除指定数据成功！");
		} catch (Exception e) {
			logger.error("删除指定数据失败！" + e);
		}
    }

~~~

####  11.删除索引类型表所有数据，批量删除 

~~~java
/**
	 * 删除索引类型表所有数据，批量删除
	 * @param index
	 * @param type
	 */
	public static void deleteIndexTypeAllData(String index, String type) {
		SearchResponse response = client.prepareSearch(index).setTypes(type)
				.setQuery(QueryBuilders.matchAllQuery()).setSearchType(SearchType.DFS_QUERY_THEN_FETCH)
					.setScroll(new TimeValue(60000)).setSize(10000).setExplain(false).execute().actionGet();
		BulkRequestBuilder bulkRequest = client.prepareBulk();
		while (true) {
			SearchHit[] hitArray = response.getHits().getHits();
			SearchHit hit = null;
			for (int i = 0, len = hitArray.length; i < len; i++) {
				hit = hitArray[i];
				DeleteRequestBuilder request = client.prepareDelete(index, type, hit.getId());
				bulkRequest.add(request);
			}
			BulkResponse bulkResponse = bulkRequest.execute().actionGet();
			if (bulkResponse.hasFailures()) {
				logger.error(bulkResponse.buildFailureMessage());
			}
			if (hitArray.length == 0) break;
			response = client.prepareSearchScroll(response.getScrollId())
							.setScroll(new TimeValue(60000)).execute().actionGet();
		}
	}

---------------------------------------------------------------------------
    /**
     * 同步批量删除文档
     */
    public long deleteDocByQuery(String index, QueryBuilder query) {
        BulkByScrollResponse response = DeleteByQueryAction.INSTANCE.newRequestBuilder(client)
                .filter(query)
                .source(index)
                .get();
        return response.getDeleted();
    }    
---------------------------------------------------------------------------
    /**
     * 异步批量删除文档
     */
    public void deleteAsyncDocByQuery(String index, QueryBuilder query) {
        DeleteByQueryAction.INSTANCE
                .newRequestBuilder(client)
                .filter(query)
                .source(index)
                .execute(new ActionListener<BulkByScrollResponse>() {
                    /**
                     * 删除成功回调方法
                     * */
                    @Override
                    public void onResponse(BulkByScrollResponse bulkByScrollResponse) {
                        long deleted = bulkByScrollResponse.getDeleted();
                    }

                    /**
                     * 删除失败回调方法
                     * */
                    @Override
                    public void onFailure(Exception e) {

                    }
                });
    }    
~~~

#### 12.批量插入数据 

~~~java
/**
     * 功能描述：批量插入数据
     * @param index    索引名
     * @param type     类型
     * @param jsonList 批量数据
     */
    @SuppressWarnings("deprecation")
	public void bulkInsertData(String index, String type, List<String> jsonList) {
        BulkRequestBuilder bulkRequest = client.prepareBulk();
        jsonList.forEach(item -> {
            bulkRequest.add(client.prepareIndex(index, type).setSource(item));
        });
        BulkResponse bulkResponse = bulkRequest.get();
        if(!bulkResponse.hasFailures()) {
        	System.out.println(bulkResponse.getItems().length + "条数据插入完成！");
        }
    }

~~~

#### 13.通过prepareGet方法获取指定文档信息 

~~~
 /**
     * 通过prepareGet方法获取指定文档信息
     */
    public static void getOneDocument(String index, String type, String id) {
    	// 搜索数据  
        GetResponse response = client.prepareGet(index, type, id)
//                .setOperationThreaded(false)    // 线程安全
                .get();
        System.out.println(response.isExists());  // 查询结果是否存在
        System.out.println("***********"+response.getSourceAsString());//获取文档信息
//        System.out.println(response.toString());//获取详细信息
    }

~~~

#### 14.通过prepareSearch方法获取指定索引所有文档信息 

~~~java
/**
     * 通过prepareSearch方法获取指定索引所有文档信息
     */
    public static List<Map<String, Object>> getDocuments(String index) {
    	List<Map<String, Object>> mapList = new ArrayList<>();
    	// 搜索数据  
    	SearchResponse response = client.prepareSearch(index)
//    			.setTypes("type1","type2"); //设置过滤type
//    			.setTypes(SearchType.DFS_QUERY_THEN_FETCH)  精确查询
//    			.setQuery(QueryBuilders.matchQuery(term, queryString));
//    			.setFrom(0) //设置查询数据的位置,分页用
//    			.setSize(60) //设置查询结果集的最大条数
//    			.setExplain(true) //设置是否按查询匹配度排序
    			.get(); //最后就是返回搜索响应信息
    	System.out.println("共匹配到:"+response.getHits().getTotalHits()+"条记录!");
    	SearchHit[] hits = response.getHits().getHits();
    	for (SearchHit hit : hits) {
			Map<String, Object> source = hit.getSource();
			mapList.add(source);
		}
        System.out.println(response.getTotalShards());//总条数
        return mapList;
    }

~~~

#### 15.获取指定索引库下指定type所有文档信息 

~~~java
/**
     * 获取指定索引库下指定type所有文档信息
     * @param index
     * @param type
     * @return
     */
    public static List<Map<String, Object>> getDocuments(String index, String type) {
    	List<Map<String, Object>> mapList = new ArrayList<>();
    	SearchResponse response = client.prepareSearch(index).setTypes(type).get();
    	SearchHit[] hits = response.getHits().getHits();
    	for (SearchHit hit : hits) {
			Map<String, Object> source = hit.getSource();
			mapList.add(source);
		}
    	return mapList;

~~~

#### 16.带有搜索条件的聚合查询（聚合相当于关系型数据库里面的group by） 

~~~java
/**
     * 带有搜索条件的聚合查询（聚合相当于关系型数据库里面的group by）
     * @param index
     * @param type
     * @return
     */
    public static Map<String, Long> searchBucketsAggregation(String index, String type) {
    	long total = 0;
    	Map<String, Long> rtnMap = new HashMap<>();
    	SearchRequestBuilder searchRequestBuilder = client.prepareSearch(index).setTypes(type);
    	//搜索条件  
    	String dateStr = DateUtil.getDays();
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        /*queryBuilder.must(QueryBuilders.matchQuery("source", "resource"))精确匹配*/
        queryBuilder.filter(QueryBuilders.boolQuery()
        					.must(QueryBuilders.rangeQuery("logTime")
        							.gte(dateStr + "000000")
        							.lte(dateStr + "235959") //时间为当天
        							.format("yyyyMMddHHmmss")));//时间匹配格式
        // 获取当日告警总数
//        long total = searchRequestBuilder.setQuery(queryBuilder).get().getHits().getTotalHits();
    	// 聚合分类（以告警类型分类）
    	TermsAggregationBuilder teamAggBuilder = AggregationBuilders.terms("source_count").field("source.keyword");
    	searchRequestBuilder.addAggregation(teamAggBuilder);
    	// 不指定 "size":0 ，则搜索结果和聚合结果都将被返回,指定size：0则只返回聚合结果
    	searchRequestBuilder.setSize(0);
    	searchRequestBuilder.setQuery(queryBuilder);
    	SearchResponse response = searchRequestBuilder.execute().actionGet();
    	
//    	System.out.println("++++++聚合分类："+response.toString());
    	
    	// 聚合结果处理
    	Terms genders = response.getAggregations().get("source_count");
        for (Terms.Bucket entry : genders.getBuckets()) {
            Object key = entry.getKey();      // Term  
            Long count = entry.getDocCount(); // Doc count
            
            rtnMap.put(key.toString(), count);
            
//            System.out.println("Term: "+key);  
//            System.out.println("Doc count: "+count);  
        }
        if(!rtnMap.isEmpty()) {
        	if(!rtnMap.containsKey("system")) {
        		rtnMap.put("system", 0L);
        	}
        	if(!rtnMap.containsKey("resource")) {
        		rtnMap.put("resource", 0L);
        	}
        	if(!rtnMap.containsKey("scheduler")) {
        		rtnMap.put("scheduler", 0L);
        	}
        	total = rtnMap.get("system") + rtnMap.get("resource") + rtnMap.get("scheduler");
        }
        if(total != 0) {
        	rtnMap.put("total", total);
        }
        return rtnMap;
    }

~~~

#### 17.当日流数据总量汇总 

~~~
/**
     * 当日流数据总量汇总
     * @param index
     * @param type
     * @param dataworkerType
     * @return
     */
    public static Map<String, Long> searchBucketsAggregation(String index, String type, String dataworkerType) {
    	Map<String, Long> rtnMap = new HashMap<>();
    	long count = 0;
    	SearchRequestBuilder searchRequestBuilder = client.prepareSearch(index).setTypes(type);
    	
//    	SumAggregationBuilder sAggBuilder = AggregationBuilders.sum("agg").field("count.keyword");
    	
    	//搜索条件  
    	String dateStr = DateUtil.getDays();
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
//        queryBuilder.must(QueryBuilders.matchQuery("dataworkerType", dataworkerType))
        queryBuilder.must(QueryBuilders.matchQuery("dataworkerType", dataworkerType))
        			.filter(QueryBuilders.boolQuery()
        					.must(QueryBuilders.rangeQuery("logTime")
        							.gte(dateStr + "000000")
        							.lte(dateStr + "235959")
        							.format("yyyyMMddHHmmss")));
    	searchRequestBuilder.setQuery(queryBuilder);
//    	searchRequestBuilder.addAggregation(sAggBuilder);
    	SearchResponse response = searchRequestBuilder.execute().actionGet();
    	
    	System.out.println("++++++条件查询结果："+response.toString());
    	
    	SearchHit[] hits = response.getHits().getHits();
    	for (SearchHit searchHit : hits) {
			Object object = searchHit.getSource().get("count");
			if(object != null && !"".equals(object)) {
				System.out.println("=============Count:"+object.toString());
				count += Long.parseLong(object.toString());
			}
		}
    	System.out.println("======流数据量：" + count);
    	rtnMap.put(dataworkerType + "Total", count);
    	System.out.println("======rtnMap:"+rtnMap.toString());
        return rtnMap;
    }

~~~

#### 18.读取索引类型表指定列名的平均值 

~~~java
/**
	 * 读取索引类型表指定列名的平均值
	 * @param index
	 * @param type
	 * @param avgField
	 * @return
	 */
	public static double readIndexTypeFieldValueWithAvg(String index, String type, String avgField) {
		String avgName = avgField + "Avg";
		AvgAggregationBuilder aggregation = AggregationBuilders.avg(avgName).field(avgField);
		SearchResponse response = client.prepareSearch(index).setTypes(type)
				.setQuery(QueryBuilders.matchAllQuery())
					.addAggregation(aggregation).execute().actionGet();
		Avg avg = response.getAggregations().get(avgName);
		return avg.getValue();
	}

~~~

#### 19.读取索引类型表指定列名的总和 

~~~java
/**
	 * 读取索引类型表指定列名的总和
	 * @param index
	 * @param type
	 * @param sumField
	 * @return
	 */
	public static Map<String, Long> readIndexTypeFieldValueWithSum(String index, String type, String dataworkerType, String sumField) {
		Map<String, Long> rtnMap = new HashMap<>();
		long count = 0;
		// 聚合结果
		String sumName = sumField + "Sum";
		// 搜索条件  
    	String dateStr = DateUtil.getDays();
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        queryBuilder.must(QueryBuilders.matchQuery("dataworkerType", dataworkerType))
        			.filter(QueryBuilders.boolQuery()
        					.must(QueryBuilders.rangeQuery("logTime")
        							.gte(dateStr + "000000")
        							.lte(dateStr + "235959")
        							.format("yyyyMMddHHmmss")));
	    // 时间前缀匹配（如：20180112）
//        PrefixQueryBuilder preQueryBuild = QueryBuilders.prefixQuery(dataworkerType, dateStr);
        // 模糊匹配
//        FuzzyQueryBuilder fuzzyQueryBuild = QueryBuilders.fuzzyQuery(name, value);
        // 范围匹配
//        RangeQueryBuilder rangeQueryBuild = QueryBuilders.rangeQuery(name);
        // 查询字段不存在及字段值为空 filterBuilder = QueryBuilders.boolQuery().should(new BoolQueryBuilder().mustNot(existsQueryBuilder)) .should(QueryBuilders.termsQuery(field, ""));
//    	ExistsQueryBuilder existsQueryBuilder = QueryBuilders.existsQuery(field);
        // 对某字段求和聚合（sumField字段）
		SumAggregationBuilder aggregation = AggregationBuilders.sum(sumName).field(sumField);
		SearchResponse response = client.prepareSearch(index).setTypes(type)
				.setQuery(QueryBuilders.matchAllQuery())
				.setQuery(queryBuilder)
					.addAggregation(aggregation).execute().actionGet();
		Sum sum = response.getAggregations().get(sumName);
		count = new Double(sum.getValue()).longValue();
		rtnMap.put(dataworkerType + "Total", count);
    	System.out.println("======rtnMap:"+rtnMap.toString());
		return rtnMap;
        							
~~~

#### 20.按时间统计聚合 

~~~java
/**
     * 按时间统计聚合
     * @param index
     * @param type
     */
    public static void dataHistogramAggregation(String index, String type) {  
        try {  
            SearchRequestBuilder searchRequestBuilder = client.prepareSearch(index).setTypes(type);  
              
            DateHistogramAggregationBuilder field = AggregationBuilders.dateHistogram("sales").field("value");  
            field.dateHistogramInterval(DateHistogramInterval.MONTH);  
//          field.dateHistogramInterval(DateHistogramInterval.days(10))  
            field.format("yyyy-MM");
            
            //强制返回空 buckets,既空的月份也返回
            field.minDocCount(0);
            
            // Elasticsearch 默认只返回你的数据中最小值和最大值之间的 buckets
            field.extendedBounds(new ExtendedBounds("2018-01", "2018-12"));
              
            searchRequestBuilder.addAggregation(field);  
            searchRequestBuilder.setSize(0);  
            SearchResponse searchResponse = searchRequestBuilder.execute().actionGet();  
              
            System.out.println(searchResponse.toString());  
              
            Histogram histogram = searchResponse.getAggregations().get("sales");  
            for (Histogram.Bucket entry : histogram.getBuckets()) {  
//              DateTime key = (DateTime) entry.getKey();   
                String keyAsString = entry.getKeyAsString();   
                Long count = entry.getDocCount(); // Doc count  
                  
                System.out.println("======="+keyAsString + "，销售" + count + "辆");  
            }  
        } catch (Exception e) {  
             e.printStackTrace();  
        }  
   }

~~~

#### 21.统计查询 

~~~java
/**
     * 功能描述：统计查询
     * @param index 索引名
     * @param type 类型
     * @param constructor 查询构造
     * @param groupBy 统计字段
     */
    public Map<Object, Object> statSearch(String index, String type, ESQueryBuilderConstructor constructor, String groupBy) {
        Map<Object, Object> map = new HashedMap();
        SearchRequestBuilder searchRequestBuilder = client.prepareSearch(index).setTypes(type);
        //排序
        if (StringUtils.isNotEmpty(constructor.getAsc()))
            searchRequestBuilder.addSort(constructor.getAsc(), SortOrder.ASC);
        if (StringUtils.isNotEmpty(constructor.getDesc()))
            searchRequestBuilder.addSort(constructor.getDesc(), SortOrder.DESC);
        //设置查询体
        if (null != constructor) {
            searchRequestBuilder.setQuery(constructor.listBuilders());
        } else {
            searchRequestBuilder.setQuery(QueryBuilders.matchAllQuery());
        }
        int size = constructor.getSize();
        if (size < 0) {
            size = 0;
        }
        if (size > MAX) {
            size = MAX;
        }
        //返回条目数
        searchRequestBuilder.setSize(size);
        searchRequestBuilder.setFrom(constructor.getFrom() < 0 ? 0 : constructor.getFrom());
        SearchResponse sr = searchRequestBuilder.addAggregation(
                AggregationBuilders.terms("agg").field(groupBy)
        ).get();
        Terms stateAgg = sr.getAggregations().get("agg");
        Iterator<Terms.Bucket> iter = (Iterator<Terms.Bucket>) stateAgg.getBuckets().iterator();
        while (iter.hasNext()) {
            Terms.Bucket gradeBucket = iter.next();
            map.put(gradeBucket.getKey(), gradeBucket.getDocCount());
        }
        return map;
    }

~~~

#### 22.统计查询 

~~~java
/**
     * 功能描述：统计查询
     * @param index       索引名
     * @param type 	  类型
     * @param constructor 查询构造
     * @param agg         自定义计算
     */
    /*public Map<Object, Object> statSearch(String index, String type, ESQueryBuilderConstructor constructor, AggregationBuilder agg) {
        if (agg == null) {
            return null;
        }
        Map<Object, Object> map = new HashedMap();
        SearchRequestBuilder searchRequestBuilder = client.prepareSearch(index).setTypes(type);
        //排序
        if (StringUtils.isNotEmpty(constructor.getAsc()))
            searchRequestBuilder.addSort(constructor.getAsc(), SortOrder.ASC);
        if (StringUtils.isNotEmpty(constructor.getDesc()))
            searchRequestBuilder.addSort(constructor.getDesc(), SortOrder.DESC);
        //设置查询体
        if (null != constructor) {
            searchRequestBuilder.setQuery(constructor.listBuilders());
        } else {
            searchRequestBuilder.setQuery(QueryBuilders.matchAllQuery());
        }
        int size = constructor.getSize();
        if (size < 0) {
            size = 0;
        }
        if (size > MAX) {
            size = MAX;
        }
        //返回条目数
        searchRequestBuilder.setSize(size);
        searchRequestBuilder.setFrom(constructor.getFrom() < 0 ? 0 : constructor.getFrom());
        SearchResponse sr = searchRequestBuilder.addAggregation(
                agg
        ).get();
        Terms stateAgg = sr.getAggregations().get("agg");
        Iterator<Terms.Bucket> iter = (Iterator<Terms.Bucket>) stateAgg.getBuckets().iterator();
        while (iter.hasNext()) {
            Terms.Bucket gradeBucket = iter.next();
            map.put(gradeBucket.getKey(), gradeBucket.getDocCount());
        }
        return map;
    }*/

~~~

#### 23.范围查询 

~~~java
/**
     * 范围查询
     * @throws Exception
     */
    public static void rangeQuery() {    	
    	//查询字段不存在及字段值为空 filterBuilder = QueryBuilders.boolQuery().should(new BoolQueryBuilder().mustNot(existsQueryBuilder)) .should(QueryBuilders.termsQuery(field, ""));
//    	ExistsQueryBuilder existsQueryBuilder = QueryBuilders.existsQuery(field);
    	
        //term精确查询
		//QueryBuilder queryBuilder = QueryBuilders.termQuery("age", 50) ;  //年龄等于50
        //range查询
        QueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery("age").gt(20); //年龄大于20
        SearchResponse searchResponse = client.prepareSearch("index_test")
              .setTypes("type_test")
              .setQuery(rangeQueryBuilder)     //query
              .setPostFilter(QueryBuilders.rangeQuery("age").from(40).to(50)) // Filter
//              .addSort("age", SortOrder.DESC)
              .setSize(120)   // 不设置的话，默认取10条数据
              .execute().actionGet();
        SearchHits hits = searchResponse.getHits();
        System.out.println("查到记录数："+hits.getTotalHits());
        SearchHit[] searchHists = hits.getHits();
        if(searchHists.length>0){
           for(SearchHit hit:searchHists){
              String name =  (String) hit.getSource().get("username");
              Integer age = Integer.parseInt(hit.getSource().get("age").toString());
              System.out.println("姓名：" + name + " 年龄：" + age);
           }
        }
     }

~~~

#### 24.时间范围查询 

~~~java
/**
     * 时间范围查询
     * @param index
     * @param type
     * @param startDate
     * @param endDate
     */
    public static void rangeQuery(String index, String type, String startDate, String endDate) {
    	BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();      
//        boolQueryBuilder.must(queryBuilders);      
        boolQueryBuilder.filter(QueryBuilders.boolQuery().must(      
                QueryBuilders.rangeQuery("time").gte(startDate).lte(endDate).format("yyyyMMddHHmmss")));      
      
        SearchResponse searchResponse = client.prepareSearch(index).setTypes(type)      
                .setSearchType(SearchType.DFS_QUERY_THEN_FETCH)      
                .setQuery(boolQueryBuilder)  
                .addAggregation(AggregationBuilders.terms("value_count").field("value.keyword")).get();   
                //Terms Aggregation  名称为terms1_count 字段为field1   下面的也类似  
//                .addAggregation(AggregationBuilders.terms("terms2_count").field("field2"));
        
        System.out.println("时间范围查询结果： "+searchResponse.toString());
        
        SearchHit[] hits = searchResponse.getHits().getHits();
    	List<Map<String, Object>> mapList = new ArrayList<>();
    	for (SearchHit searchHit : hits) {
			Map<String, Object> map = searchHit.getSource();
			mapList.add(map);
		}
        System.out.println(mapList.toString());
    }

~~~

#### 25.Scroll

~~~java
/**
     * 在Elasticsearch老版本中做数据遍历一般使用Scroll-Scan。Scroll是先做一次初始化搜索把所有符合搜索条件的结果缓存起来生成一个快照，
     * 然后持续地、批量地从快照里拉取数据直到没有数据剩下。而这时对索引数据的插入、删除、更新都不会影响遍历结果，因此scroll 并不适合用来做实时搜索。
     * Scan是搜索类型，告诉Elasticsearch不用对结果集进行排序，只要分片里还有结果可以返回，就返回一批结果。
     * 在5.X版本中SearchType.SCAN已经被去掉了。根据官方文档说明，使用“_doc”做排序可以达到更高性能的Scroll查询效果，
     * 这样可以遍历所有文档而不需要进行排序。
     * @param index
     * @param type
     */
    @SuppressWarnings("deprecation")
	public static void scroll(String index, String type) {
    	System.out.println("scroll()方法开始.....");
    	List<JSONObject> lst = new ArrayList<JSONObject>();
        SearchResponse searchResponse = client.prepareSearch(index)  
                .setTypes(type)  
                .setQuery(QueryBuilders.matchAllQuery())  
                .addSort(SortBuilders.fieldSort("_doc"))
                .setSize(30)  
                // 这个游标维持多长时间  
                .setScroll(TimeValue.timeValueMinutes(8)).execute().actionGet();  
          
        System.out.println("getScrollId: "+searchResponse.getScrollId());  
        System.out.println("匹配记录数："+searchResponse.getHits().getTotalHits());  
        System.out.println("hits长度："+searchResponse.getHits().hits().length);  
        for (SearchHit hit : searchResponse.getHits()) {
            String json = hit.getSourceAsString();
            try {
            	JSONObject jsonObject = new JSONObject(json);
            	lst.add(jsonObject);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        System.out.println("======" + lst.toString());
        System.out.println("======" + lst.get(0).get("username"));
        // 使用上次的scrollId继续访问  
//        croll scroll = new ScrollTest2();
//        do{  
//            int num = scroll.scanData(esClient,searchResponse.getScrollId())
//            if(num ==0) break;  
//        }while(true);  
        System.out.println("------------------------------END");
    }

~~~

#### 26.分词

~~~java
/**
	 * 分词
	 * @param index
	 * @param text
	 */
	public static void analyze(String index, String text) {
		TransportClient client = StaticContant.ESCLIENT;
		AnalyzeRequestBuilder request = new AnalyzeRequestBuilder(client, AnalyzeAction.INSTANCE, index, text);
		request.setAnalyzer("ik");
		List<AnalyzeToken> analyzeTokens = request.execute().actionGet().getTokens();
		for (int i = 0, len = analyzeTokens.size(); i < len; i++) {
			AnalyzeToken analyzeToken = analyzeTokens.get(i);
			System.out.println(analyzeToken.getTerm());
		}
	}

~~~



### 参考

~~~http
增，删，改，批量 操作
https://blog.csdn.net/wuyzhen_csdn/article/details/52381697

聚合
https://blog.csdn.net/wf787283810/article/details/79035988

搜索，查找

~~~

