## 3.索引和分词器

- 正排索引：文档Id到文档内容/单词的关联关系
- 倒排索引：单词到文档id的关联关系

### 3.1.倒排索引

倒排索引是搜索引擎的核心，主要包含两部分：

- 单词词典(Term Dictionary)：记录所有文档的单词，一般都比较大，记录单词到倒排列表的关联信息
- 倒排列表(Posting List)：记录了单词对应的文档集合，由倒排索引项(Posting)组成，主要包含如下信息：
  - 文档id，用于获取原始信息
  - 单词频率(TF,Term Frequenry)，记录该单词在文档中出现次数，用于后续相关性算分
  - 位置(Position),记录单词在文档中的分词位置(多个)，用于做词语搜索(Phrase Query)
  - 偏移量，记录单词在文档的开始和结束位置，用于做高亮显示

### 3.2.分词器组成

分词器组成如下：

- Character Filters：针对原始文本进行处理，比如去除html特殊标记符

~~~
POST _analyze
{
    "tokenizer": "keyword",
    "char_filter": ["html_strip"],
    "text": "<p>I&apos;m so<b>happy</b>!</p>"
}
~~~

- Tokenizer：将原始文本按照一定规律切分为单词，自带如下
  - standard按照单词进行分割
  - letter按照非字符类进行分割
  - whitespace按照空格进行分割
  - UAX URL Email按照standard分割，但不会分割邮箱和url
  - NGram和Edge NGram连词分割
  - Path Hierarchy按照文件路径进行切割

- Token Filters：针对tokenizer处理的单词进行在加工，比如转小写/删除或新增等处理，自带如下：
  - lowercase将所有term转换为小写
  - stop删除stop words
  - NGram和Edge NGram连词分割
  - Synonym添加近义词的term

~~~
POST _analyze
{
    "text": "a Hello world!",
    "tokenizer": "standard",
    "filter": [
        "stop",
        "lowercase",
        {
            "min_gram": 2,
            "max_gram": 4
        }
    ]
}
~~~

### 3.3.Analyze API

~~~
1.直接使用analyze进行测试，如下接口
POST _analyze
{
    "analyze":"standard", //分词器
    "text":"hello world" //测试样本
}

2.直接指定索引中的字段进行测试，接口如下：
POST test_index/_analyze
{
    "field": "username",
    "text": "hello world!"
}

3.自定义分词器进行测试
POST _anaylze
{
    "tokenizer": "standard",
    "filter": ["lowercase"], //自定义analyze
    "text": "Hello World"
}
~~~

### 3.4.ES自带分词器

- Standard
  - 默认分词器，按词切分，支持多语言，小写处理
- Simple
  - 按照非字母切分，小写处理
- Whitespace
  - 按照空格切分
- Stop
  - stop word指语气助词等修饰性的词语，比如the an 的 这等
  - 相比Simple多了Stop Word处理
- Keyword
  - 不分词，直接将输入作为一个单词输出
- Pattern
  - 通过正则表达式自定义分割符
  - 默认是\W+，即非字词的符号作为分隔符
- Language
  - 提供了30+常用语言的分词器

### 3.5.中文分词器

- IK
  - 实现中英文单词的切分，支持ik_smart,ik_maxword等模式
  - 可自定义词库，支持热更新分词词典
- jieba
  - python中最流行的分词系统，支持分词和词性标注
  - 支持繁体分词/自定义词典/并行分词等
- 基于自然语言处理的分词系统
  - Hanlp：由一系列模型与算法组成的Java工具包，目标是普及自然语言处理在生产环境中的应用
  - THULAC：有清华大学自然语言处理与社会人文计算实验室研制推出的一套中文词法分析工具包，具有中文分词和词性标注功能

### 3.6.自定义分词器

~~~
语法：
PUT test_index
{
    "settings": {
        "analysis": {
            "char_filter": {},
            "tokenizer": {},
            "filter": {},
            "analyzer": {}
        }
    }
}

示例1：
PUT test_index
{
    "setting": {
        "analysis": {
            "analyzer": {
                "my_custom_analyzer": {
                    "type": "custom",
                    "tokenizer": "standard",
                    "char_filter": [
                        "html_strip"
                    ],
                    "filter": [
                        "lowercase",
                        "asciifolding"
                    ]
                }
            }
        }
    }
}
使用：
POST test_index/_analyze
{
    "analyzer": "my_custom_analyzer",
    "text": "Is this <b>a box</b>?"
}
----------------------------------------------------------------------------
示例2：
PUT test_index
{
    "setting": {
        "analysis": {
            "analyzer": {
                "my_custom_analyzer": {
                    "type": "custom",
                    "char_filter": [
                        "emoticons"
                    ],
                    "tokenizer": "punctuation",
                    "filter": [
                        "lowercase",
                        "english_stop"
                    ]
                }
            }
        },
        "tokenizer": {
            "punctuation": {
                "type": "pattern",
                "pattern": "[.,!?]"
            }
        },
        "char_filter": {
            "emoticons": {
                "type": "mapping",
                "mappings": [
                    ":) => _happy_",
                    ":( => _sad_"
                ]
            }
        },
        "filter": {
            "english_stop": {
            	"type": "stop",
            	"stopwords": "_english_"
            }
        }
    }
}
使用：
POST test_index/_analyze
{
    "analyzer": "my_custom_analyzer",
    "text": "I'm a :) person,and you?"
}
~~~

### 3.7.分词使用说明

~~~
1.索引时分词
索引词分词时通过配置Index Mapping中每个字段的analyzer属性实现的，不指定分词，使用默认standard
如下：
PUT test_index
{
    "mappings": {
        "doc": {
            "properties": {
                "title": {
                    "type": "text",
                    "analyzer": "whitespace" //指定分词
                }
            }
        }
    }
}

2.查询时分词
查询时分词的指定方式有如下几种：
1）查询时通过analyzer指定分词器
2）通过index mapping设置search_analyzer实现

POST test_index/_search
{
    "query": {
        "match": {
            "message": {
                "query": "hello",
                "analyzer": "standard"
            }
        }
    }
}

PUT test_index
{
    "mappings": {
        "doc": {
            "properties": {
                "title": {
                    "type": "text",
                    "analyzer": "whitespace" //指定分词
                    "search_analyzer": "standard"
                }
            }
        }
    }
}

~~~

4.Mapping





## 4.Mapping设置

### 4.1.自定义mapping

~~~
1.语法
PUT my_index
{
    "mappings": { //mappings关键字
        "doc": { //type名称
            "properties": {
                "title": {
                    "type": "text"
                },
                "name": {
                    "type": "keyword"
                },
                "age": {
                    "type": "integer"
                }
            }
        }
    }
}

注：Mapping中的字段类型一旦设定之后，禁止直接修改，原因如下：
1.Lucence实现的倒排索引生成后不允许修改
如需要修改，需要重建索引，然后reindex操作

-------------------------------------------------------------------
2.允许新增字段
通过dynamic参数来控制字段的新增
-true(默认):允许自动新增字段
-false：不允许自动新增字段，但文档可以正常写入，但无法对字段进行查询等操作
-strict:文档不能写入，报错

PUT my_index
{
	"mappings": { //mappings关键字
		"dynamic": false,
        "doc": { //type名称
            "properties": {
                "title": {
                    "type": "text"
                },
                "name": {
                    "type": "keyword"
                },
                "age": {
                    "type": "integer"
                },
                "social_networks": {
                    "dynamic": true,
                    "properties": {                  
                    }
                }
            }
        }
    }    
}

~~~

### 4.2.copy_to参数

- 将该字段的值复制到目标字段，实现类似_all的作用
- 不会出现在_source中，指用来搜索

~~~
PUT my_index
{
    "mappings": {
        "doc": {
            "properties": {
                "first_name": {
                    "type": "text",
                    "cope_to": "full_name"
                },
                "last_name": {
                    "type": "text",
                    "cope_to": "full_name"
                },
                "full_name": {
                    "type": "text"
                }
            }
        }
    }
}
~~~

### 4.3.index参数

控制当前字段是否索引，默认为true，即记录索引，false不记录，即不可搜索

~~~
PUT my_index
{
    "mappings": {
        "doc": {
            "properties": {
                "cookie": {
                    "type": "text",
                    "index": false
                }
            }
        }
    }
}
~~~

### 4.4.index_options参数

- index_options用于控制倒排索引记录的内容，有如下4种配置
  - docs只记录doc id
  - freqs记录doc id和term frequencies(出现次数)
  - positions记录doc id和term frequencies和term position(出现位置)
  - offsets记录doc id和term frequencies和term position和character offsets(开始位置，结束位置)
- text类型默认配置为positions，其他默认为docs
- 记录内容越多，占用空间越大

~~~
PUT my_index
{
    "mappings": {
        "doc": {
            "properties": {
                "cookie": {
                    "type": "text",
                    "index_options": "offsets"
                }
            }
        }
    }
}
~~~

### 4.5.null_value参数

- 当字段遇到null值时的处理策略，默认为null，即为空，此时es会忽略该值。可以通过设定该值设定字段的默认值

~~~
PUT my_index
{
    "mappings": {
        "doc": {
            "properties": {
                "cookie": {
                    "type": "keyword",
                    "null_value": "NULL"
                }
            }
        }
    }
}
~~~

### 4.6.数据类型

- 字符类型 text,keyword
- 数值类型 long,integer,shor,byte,double,float,half_float,scaled_float
- 日期类型 date
- 布尔类型 boolean
- 二进制类型 binary
- 范围类型 integer_range,float_range,long_range,double_range,date_range
- 数组类型 array
- 对象类型 object
- 嵌套类型 nested object
- 地理位置类型 geo_point geo_shape
- 记录ip地址 ip
- 实现自动补全completion
- 记录分词数 token_count
- 记录字符串hash值murmur3

- 多字段特性multi_fields
  - 允许多同一个字段采用不同的配置，比如分词，常见的例子如对人名实现拼音搜索，只需要在人名中新增一个字段为pinyin即可

~~~
{
    "test_index": {
        "mappings": {
            "doc": {
                "properties": {
                    "username": {
                        "type": "text",
                        "fields": {
                            "pinyin": {
                                "type": "text",
                                "analyzer": "pinyin"
                            }
                        }
                    }
                }
            }
        }
    }
}
~~~

### 4.7.dynamic_mapping

	es可以自动识别文档字段类型，从而降低用户使用成本

#### 4.7.1.日期与数字识别

- 日期的自动识别可以自动配置日期格式，以满足各种需求
  - 默认是：["strict_date_optional_time","yyyy/MM/dd HH:mm:ss Z||yyyy/MM/dd Z"]
  - strict_date_optional_time是ISO datetime的格式，完整格式类似下面：
    - YYYY-MM-DDThh:mm:ssTZD(eg 1997-07-16T19:20:30+01:00)
  - dynamic_date_formats可以自定义日期类型
  - date_detection可以关闭日期自动识别的机制

~~~
自定义日期识别格式
PUT my_index 
{
    "mappings": {
        "my_type": {
            "dynamic_date_formats": ["MM/dd/yyyy"]
        }
    }
}

关闭日期自动识别机制
PUT my_index 
{
    "mappings": {
        "my_type": {
            "date_detection": false
        }
    }
}
~~~

#### 4.7.2.自动识别数字

- 字符串是数字时，默认不会自动识别为整形，因为字符串中出现数字是完全合理的
  - numeric_detection可以开启字符串中数字的自动识别，如下所示：

~~~

~~~

### 4.8.dynamic templates

- 允许根据es自动识别的数据类型，字段类型等来动态设定字段类型，可以实现如下效果：
  - 所有字符串类型都设定为keyword类型，即默认不分词
  - 所有以message开头的字段都可以设定为text类型，即分词
  - 所有以long_开头的字段都设定为long类型
  - 所有自动匹配double类型的都设定为float类型，以节省空间

~~~
PUT test_index
{
    "mappings": {
        "doc": {
            "dynamic_templates": [ //数组，可以指定多个匹配规则
                {
                    "strings": { //template的名称
                        "match_mapping_type": "string", //匹配规则
                        "mapping": { //设置mapping信息
                            "type": "keyword"
                        }
                    }
                }
            ]
        }
    }
}
~~~

- 匹配规则一般有如下几个参数：
  - match_mapping_type匹配es自动识别的字段类型，如boolean，long，string等
  - match,unmatch匹配字段名
  - path_match,path_unmatch匹配路径

注意：多个规则一起使用时，是从上到下匹配，也就是说匹配第一个后，后面的规则不起作用

案例：

~~~
1.将字符串类型设置为keyword类型
PUT test_index
{
    "mappings": {
        "doc": {
            "dynamic_templates": [ //数组，可以指定多个匹配规则
                {
                    "strings_as_keywords": { //template的名称
                        "match_mapping_type": "string", //匹配规则
                        "mapping": { //设置mapping信息
                            "type": "keyword"
                        }
                    }
                }
            ]
        }
    }
}

2.以message开头的字段都设置为text类型
PUT test_index
{
    "mappings": {
        "doc": {
            "dynamic_templates": [ //数组，可以指定多个匹配规则
                {
                    "strings_as_text": { //template的名称
                        "match_mapping_type": "string", //匹配规则
                        "match": "message*"
                        "mapping": { //设置mapping信息
                            "type": "text"
                        }
                    }
                }
            ]
        }
    }    
}
~~~

### 4.9.索引模板(index template)

- 索引模板，英文名为Index Template，主要用于在新建索引时自动应用预先设定的设置
  - 可以设定索引的配置和mapping
  - 可以有多个模板，可以order设置，order大的覆盖小的配置

~~~
PUT _template/test_template //templatem关键字
{
    "index_patterns": ["te*","bar*"], //匹配的索引名称
    "order": 0, //order顺序配置
    "settings": {
        "number_of_shards": 1
    },
    "mappings": {
    	"doc": {
            "_source": {
                "enabled": false
            },
            "properties": {
                "name": {
                    "type": "keyword"
                }
            }
    	}
    }    
}
~~~

### 4.10._source参数

~~~
1.禁用_source
PUT tweets
{
  "mappings": {
    "_doc": {
      "_source": {
        "enabled": false
      }
    }
  }
}

2.包含和排除某些字段(includes/excludes)
PUT logs
{
  "mappings": {
    "_doc": {
      "_source": {
        "includes": [
          "*.count",
          "meta.*"
        ],
        "excludes": [
          "meta.description",
          "meta.other.*"
        ]
      }
    }
  }
}

案例：
PUT logs/_doc/1
{
  "requests": {
    "count": 10,
    "foo": "bar" 
  },
  "meta": {
    "name": "Some metric",
    "description": "Some metric description", 
    "other": {
      "foo": "one", 
      "baz": "two" 
    }
  }
}

GET logs/_search
{
  "query": {
    "match": {
      "meta.other.foo": "one" 
    }
  }
}
~~~







## 5.Search API

~~~
GET /_serch
GET /my_index/_search
GET /my_index1,my_index2/_search
GET /my_*/_search //指定索引查询，可以一次查询多个
~~~

- 查询主要的两种形式
  - URI Search
    - 操作简单，方便通过命令行测试
    - 仅包含部分查询语法
    - 参数说明：
      - q：指定查询的语法，语法为Query String Syntax
      - df q中不指定字段时默认查询的字段，如果不指定，es会查询所有字段
      - sort 排序
      - timeout 指定超时时间，默认不超时
      - from，size用于分页
  - Request Body Search
    - es提供的完整查询语法Query DSL(Domain Specific Language)

~~~json
1.URL Search
GET /my_index/_search?q=user:alfred&df=user&sort=age:asc&from=4&size=10&timeout=1s
注：查询user字段包含alfred的文档，结果按照age升序排列，返回第5~14个文档，如果超过1s没有结束，则以超时结束

2.Request Body Search
GET /my_index/_search
{
    "query": {
        "term": {
            "user": "alfred"
        }
    }
}
~~~

### 5.1.Query DSL

- 基于JSON定义的查询语言，主要包含如下两种类型：
  - 字段查询
    - 如term,match,range等，只针对某一个字段进行查询
  - 复合查询
    - 如bool查询等，包含一个或多个字段类查询或复合查询语句

### 5.2.字段类查询

- 字段类查询主要包括一下两类：
  - 全文匹配
    - 针对text类型的字段进行全文检索，会对查询语句先进行分词处理，如match,match_phrase等query类型
  - 单词匹配
    - 不会对查询语言做分词处理，直接去匹配字段的倒排索引，如term，terms，range等query类型

### 5.3.Match Query

- 对字段做全文索引，最基本和常用的查询类型，API示例如下：

~~~
GET /test_index/_search
{
	"profile": true,
    "query": {
        "match": { //关键字
            "username": "alfred way" //字段名
        }
    }
}

GET /test_index/_search
{
    "query": {
        "match": { //关键字
            "username": { //字段名
                "query": "alfred way",
                "operator": "and"
            } 
        }
    }
}
注：通过operator参数可以控制单词间的匹配关系，可选项为or或and
~~~

### 5.4.相关度算分

- 相关度算分是指文档与查询语句间的相关度，英文为relevance
  - 通过倒排索引可以获取与查询语句相匹配的文档列表，那么如何将最符合用户查询需求的文档放到前列呢？
  - 本质是一个排序问题，排序的依据是相关度算分
- 相关性算分的几个重要概念如下：
  - Term Frequency(TF)词频，即单词在文档中出现的次数，词频越高，相关度越高
  - Document Frequency(DF)文档频率，即单词出现的文档数
  - Inverse Document Frequency(IDF)逆向文档频率，与文档频率相反，简单理解为1/DF，即单词出现的文档数越少，相关度越高
  - Field-length Norm文档越短，相关度越高

- Es目前主要的两个相关性算分模型，如下
  - TF/IDF模型
  - BM25模型5.x之后的默认模型

- 可以通过explain参数来查询具体的相关度计算方法，但要注意：
  - es的算分是按照shard进行的，即shard的分数计算是互相独立的，所以在使用explain的时候注意分片数量
  - 可以通过设置索引的分片数为1来避免这个问题

~~~
GET /text_index/_search
{
    "explain": true,
    "query": {
        "match": {
            "username": "alfred way"
        }
    }
}
~~~

### 5.5.Match Phrase Query(短语搜索)

- 对字段作检索，有顺序要求，API示例如下：

~~~
GET /test_search_index/_search
{
    "query": {
        "match_phrase": {
            "job": "java engineer"
        }
    }
}

通过slop参数可以控制单词间的间隔
GET /test_search_index/_search
{
    "query": {
        "match_phrase": {
            "job": {
                "query": "java enginerr",
                "slop": 1
            }
        }
    }
}
~~~

### 5.6.Query String Query

- 类似于URI Search中的q参数查询

~~~
GET test_search_index/_search
{
    "query": {
        "query_string": {
            "default_field": "username", //指明默认查询的字段名
            "query": "alfred AND way" 
        }
    }
}

GET test_search_index/_search
{
    "query": {
        "query_string": {
            "fields": ["username","job"], //指明默认查询的字段名
            "query": "alfred OR (java ADN ruby)" 
        }
    }
}
~~~

### 5.7.Simple Query String

- 类似Query String,但是会忽略错误的查询语法，并且仅支持部分查询语法
- 其常用的逻辑符号如下，不能使用AND,OR,AND关键字
  - +代表AND
  - |代表OR
  - -代表NOT

~~~
GET /my_index/_search
{
    "simple_query_string": {
        "query": "alfred + way",
        "fields": ["username"]
    }
}
~~~

### 5.8.Term Terms Query

- 将查询语句作为整个单词进行查询，即不对查询语句做分词处理，如下所示： 

~~~
GET /my_inde/_search
{
	"query": {
        "term": {
            "username": "alfred"
        }
	}
}

GET /my_inde/_search
{
	"query": {
        "terms": {
            "username": ["alfred","way"]
        }
	}
}
~~~

### 5.9.Range Query

- 范围查询主要针对数值和时间类型

~~~
GET /my_index/_search
{
    "query"： {
        "range": {
            "age": {
                "gte": 10, //大于等于
                "lte": 20 //小于等于
            }
        }
    }
}

日期查询
GET /my_index/_search
{
    "query"： {
        "range": {
            "birth": {
                "gte": "1990-01-01"
            }
        }
    }
}

GET /my_index/_search
{
    "query"： {
        "range": {
            "birth": {
                "gte": "new-20y" //计算公式
            }
        }
    }
}

计算公式格式如下：
now-1d
now-1d/d
2018-01-01||+1h 加一个小时
2018-01-01||-1d 减一天
2018-01-01||/d 将时间舍入到天
2018-01-01||+1M/d 将时间舍入到天

主要的时间单位：
y - years
M - months
w - weeks
d - days
h - hours
m - minutes
s - seconds
~~~

### 5.10.复合查询(constant_score等)

- 复合查询是指包含字段类查询或复合查询的类型，主要包括以下几个类：
  - constant_score query:该查询将其内部的查询结果文档得分都设定为1或者boost的值
    - 多用于结合bool查询实现自定义得分
  - bool query
  - dis_max query
  - function_score query
  - boosting query

~~~
1.constant_score 
GET /my_index/_search
{
    "query": {
        "constant_score": {
            "filter": {
                "match": {
                    "username": "alfred"
                }
            }
        }
    }
}


~~~

### 5.11.Bool查询(must,filter,should)

- 布尔查询由一个或多个布尔子查询组成，主要包含如下4个：

| 关键字   | 备注                                           |
| -------- | ---------------------------------------------- |
| filter   | 只过滤符合条件的文档，不计算相关性分数         |
| must     | 文档必须符合must中的所有条件，会影响相关性分数 |
| must_not | 文档必须不符合must_not中的所有条件             |
| should   | 文档可以符合should中的条件，会影响相关性得分   |

~~~
语法：
GET /my_index/_search
{
    "query": {
        "bool": {
            "must": [
                {},{}
            ],
            "must_not": [
                {},{}
            ],
            "should": [
                {},{}
            ],
            "filter": [
                {}
            ]
        }
    }
}

~~~

- Filter查询只过滤符合条件的文档，不会进行相关性算分
  - es针对filter会智能缓存，因此其执行效率很高
  - 做简单的匹配查询其不考虑算分，推荐使用filter替代query等

~~~
GET /my_index/_search
{
    "query": {
        "bool": {
            "filter": [
                {
                    "term": {
                        "username": "alfred"
                    }
                }
            ]
        }
    }
}
~~~

- Should使用分两种情况：
  - bool查询中只包含should,不包含must查询
    - 只包含should时，文档必须满足至少一个条件
    - minimum_should_match可以控制满足条件的个数或者百分比
  - bool查询中同时包含should和must查询
    - 同时包含should和must时，文档不必满足should中的条件，但是如果满足条件，会增加相关性得分

~~~
GET /my_index/_search
{
    "query": {
        "bool": {
            "should": [
                { "term": { "job": "java" }},
                { "term": { "job": "ruby" }},
                { "term": { "job": "specialist" }}
            ],
            "minimum_should_match": 2
        }
    }
}

GET /my_index/_search
{
    "query": {
        "bool": {
        	"must": [
                "term": { "username": "alfred" }
        	],
            "should": [                
                { "term": { "job": "ruby" }}
            ]
        }
    }
}

~~~

### 5.12.Query VS Filter

~~~
GET /my_index/_search
{
    "query": {
        "bool": {
            "must": [ //must下是query上下文，会进行相关性算分
                {"macth": { "title": "Search"}},
                {"macth": { "content": "Elasticsearch"}}
            ],
            "filter": [ //filter不影响算分，只会过滤符合条件的文档
                {"term": {"status": "published"}},
                {"range": {"publish_date": { "gte": "2015-01-01" }}}
            ]
        }
    }
}
~~~

### 5.13.Count Vs Source Api

- Count：获取符合条件的文档数，endpoint为_count

~~~
GET /my_index/_count
{
    "query": {
        "match": {
            "username": "alfred"
        }
    }
}
~~~

- Source：过滤返回结果中_source中的字段，主要有如下几种方式：

~~~
GET /my_index/_search?_sourch=username

GET /my_index/_search
{
    "_source": flase //不返回_source
}

GET /my_index/_search
{
    "_source": ["username","age"] //返回部分字段
}

GET /my_index/_search
{
    "_source": { //返回部分字段
        "includes": "*i*",
        "excludes": "birth"
    }
}

参考：https://blog.csdn.net/napoay/article/details/62233031
PUT /my_index 
{
    ""
}
~~~





## 6.分布式介绍

- es支持集群模式，是一个分布式系统，其好处主要有两个：
  - 增大系统容量，如内存，磁盘，使得es集群可以支持PB级的数据
  - 提高系统可用性，即使部分节点停止服务，整个集群依然可以正常服务
- es集群由多个es实例组成
  - 不同集群通过集群名字来区分，可通过cluster.name进行修改，默认为elasticsearch
  - 每个es实例本质上是一个JVM进程，且有自己的名字，通过node.name进行修改

### 6.1.cerebro插件安装

~~~
地址：
https://github.com/lmenezes/cerebro
~~~

### 6.2.构建集群

- Master Node
  - 可以修改cluster state的节点称为master节点，一个集群只能有一个
  - cluster state存储在每个节点上，master维护最新版本并同步给其他节点
  - master节点是通过集群中所有节点选举产生的，可以被选举的节点称为master-eligible节点，相关配置如下：node.master:ture
- Coordinating Node
  - 处理请求的节点即为coordinating节点，该节点为所有节点默认角色，不能取消
    - 路由请求到正确的节点处理，比如创建索引的请求到master节点
- Data Node
  - 存储数据的节点即为data节点，默认节点都是data类型，相关配置如下：
    - node.data:true

### 6.3.分片



~~~
PUT /my_index
{
    "settings": {
        
    }
}
~~~

### 6.4.脑裂问题

- 解决方案为仅在可选举master-eligible节点数大于等于quorum时才可以进行master选举
  - quorum=master-eligible节点数/2+1，例如3个master-eligible节点时，quorum为2
  - 设定discovery.zen.minimum_master_nodes为quorum即可避免脑裂

### 6.5.Shard原理





## 7.Search的运行机制

- search执行的时候实际分两个步骤运作的
  - Query阶段
  - Fetch阶段

### 7.1.Query运行步骤

1. node3在接受到用户的searh请求后，会先进行Query阶段(此时Coordinating Node角色)
2. node3会在6个主副分片中随机选择3个分片，发送search request
3. 被选中的3个分片会分别执行查询并排序，返回from+size个文档id和排序值
4. Node3整合3个分片返回的form+size个文档id，根据排序值排序后选取from到from+size的文档id

流程图：

![search运行步骤](ES相关资料.assets/search运行步骤.png)

### 7.2.Fetch运行步骤

1. node3根据Query阶段获取的文档id列表去对应的shard上获取文档详情数据
2. node3向相关的分片发送multi_get请求
3. 3个分片返回文档详情数据
4. node3拼接返回的结果并返回给客户

### 7.3.相关性算分问题

- 相关性算分在shard与shard间是互相独立的，也就意味着同一个Term在IDF等值在不同的shard上是不同的。文档的相关性算分和它所处的shard相关
- 在文档数量不多时，会导致相关性算分严重不准的情况发生

解决办法：

- 设置分片数量为1个，从根本上排除问题，在文档数量不多的时候可以考虑该方案，比如百万到千万级别的文档数量
- 使用DFS Query-then-Fetch查询方式，DFS Query-then-Fetch是在拿到所有文档后再重新完整的计算一次相关性算分，耗费更多的cpu和内存，执行性能也比较低，一般不建议使用

~~~
GET /my_index/_search?search_type=dfs_query_then_fetch
{
    "query": {
        "match": {
            "name": "hello"
        }
    }
}
~~~

### 7.4.排序(sort)

- es默认会采用相关性算分排序，用户可以通过设定sorting参数来自行设定排序规则
- 按照字符串排序比较特殊，因为es有text和keyword两种类型，针对text类型排序，会报错，必须打开fielddata=true

~~~
GET /my_index/_search
{
    "sort": {
        "birth": "desc"
    }
}

GET /my_index/_search
{
    "sort": [
        { "birth": "desc" },
        { "_score": "desc" }, //相关度算分排序
        { "_doc": "desc" } //指文档内部id和索引的顺序相关(分片内唯一)
    ]
}
~~~

### 7.5.Fielddate vs DocValues

- 排序的过程实质是对字段原始内容排序的过程，这个过程中倒排索引无法发挥作用，需要用到正排索引，也就是通过文档Id和字段可以快速得到字段原始内容。
- es对此提供了2种实现方式(排序或聚合)：
  - fielddata 默认禁用
  - doc values 默认启用，除了text类型

| 对比     | FieldData                                            | DocValues                          |
| -------- | ---------------------------------------------------- | ---------------------------------- |
| 创建时机 | 搜索时即时创建                                       | 索引时创建，与倒排索引创建时机一致 |
| 创建位置 | Jvm Heap                                             | 磁盘                               |
| 优点     | 不会占用额外的磁盘资源                               | 不会占用Heap内存                   |
| 缺点     | 文档过多时，即时创建会花过多的时间，占用过多heap内存 | 减慢索引的速度，占用额外的磁盘资源 |

- FieldData
  - FieldData默认是关闭的，可以通过如下api开启
  - FieldData只针对text类型生效，其他类型无效(开启系统报错)

~~~
PUT /my_index/_mapping/doc
{
    "properties": {
        "username": {
            "type": "text",
            "fielddata": ture
        }
    }
}
注意：
1.此字符串是按照分词后的term排序，往往结果很难符合预期
2.一般是对分词聚合分析的时候开启

~~~

- Doc Values
  - Doc Values默认是启用的，可以在创建索引的时候关闭：
    - 如果后面要再开启doc values，需要做reindex操作

~~~
PUT /my_index
{
    "mappings": {
        "doc": {
            "properties": {
                "username": {
                    "type": "keyword",
                    "doc_values": false
                }
            }
        }
    }
}
~~~

- docvalue_fields字段
  - 可以通过该字段获取fielddata或者doc values中存储的内容

~~~
GET /my_index/_serch
{
    "docvalue_fields": [
        "username",
        "username.keyword",
        "age"
    ]
}
~~~

### 7.6分页和遍历

-  es提供三种方式来解决分页与遍历问题
  - form/size
  - scroll
  - search_after

#### 7.6.1.from/size

- 最常用的分页方案
  - from指明开始位置
  - size指明获取总数

- 深度分页是一个经典问题：在数据分片存储的情况下如何获取前1000个文档？
  - 获取990~1000的文档时，会在每个分片上获取1000个文档，然后再由Coordinating Node聚合所有分片的结果后再排序选取前1000个文档
  - 页数越深，处理文档越多，占用内存越多，耗时越长。尽量避免深度分页，es通过index.max_result_window限定最多到10000条数据

~~~
GET /my_index/_search
{
    "from": 1,
    "size": 2
}
~~~

#### 7.6.2.Scroll

- 遍历文档集的api，以快照的方式来避免深度分页的问题
  - 不能用来做实时搜索，因为数据不是实时的
  - 尽量不要使用复杂的sort条件，使用_doc最高效
  - 使用稍嫌复杂

使用步骤：

~~~
第一步.需要发起1个scroll search，如下所示
es在收到该请求后会根据查询条件创建文档id合集的快照

GET /my_index/_search?scroll=5m
{
    "size": 1
}

注：scroll=5m表示scroll快照的有效时间

第二步：调用scroll search的api，获取文档集合，如下所示
不断迭代调用直接返回hits.hits数组为空时停止
POST /_search/scroll
{
    "scroll": "5m", //指明有效时间
    "scroll_id": "..." //上一次调用返回的id
}

注：每次调用都会返回scroll_id，根据scroll_id来查询数据，直到hits.hits数组为空时停止
~~~

- 过多的scroll调用会占用大量内存，可以通过clear api删除过多的scroll快照

~~~
DELETE /_search/scroll
{
    "scroll_id": [
        "......",
        "......"
    ]    
}

DELETE /_search/scroll/_all
~~~

#### 7.6.3.Search_After

- 避免深度分页的性能问题，提供实时的下一页文档获取功能
  - 缺点是不能使用from参数，即不能指定页数
  - 只能下一页，不能上一页
  - 使用简单

使用步骤：

~~~
第一步：正常的搜索，但要指定sort值，并保证值唯一
GET /my_index/_search
{
    "size": 1,
    "sort": {
        "age": "desc",
        "_id": "desc"
    }
}

返回：
{
    ...
    "hits": {
        "total": 6,
        "hits": [
            ...
            {
                "_index": "test_search_index",
                "_type": "doc",
                "_id": "4"
            },
            "sort": [
                28,"2"
            ]
        ]
    }
}

第二步：使用上一步最后一个文档的sort值进行查询
GET /my_index/_search
{
    "size": 1,
    "search_after": [ 28,"2" ],
    "sort": {
        "age": "desc",
        "_id": "desc"
    }
}
~~~

## 8.聚合分析

- 为了便于理解，es将聚合分析主要分为如下4类
  - Bucket，分桶类型，类似SQL中的GROUP BY语法
  - Metric，指标分析类型，如计算最大值，最小值，平均值等
  - Pipeline，管道分析类型，基于上一级的聚合分析结果进行再分析
  - Matrix，矩阵分析类型

聚合分析语法：

~~~
GET /{index}/_search
{
  "aggs": { //关键字,与query同级
    "{aggregation_name}": { //聚合分析名称
        "{aggregation_type}": { <aggregation_bady> }
        [,"meta": { [<meta_data_body>] }]?
        [,"aggs": { [<sub_aggregation>]+ }]? //子聚合
    }
	[,"<aggregation_name_2>": {...}] * //可以包含多个聚合分析
  }
}

aggregations：集合操作命令(也可简化为aggs)关键字,以下使用aggs替代
aggregation_name:用户定义的聚合关联的逻辑名,例如：avg_price。这些逻辑名也用来唯一地标识响应里面的聚合结果。
aggregation_type:每一个聚合拥有一个特定类型，通常作为聚合的第一个关键字
~~~

### 8.1.Metric聚合分析

- 主要分为两类
  - 单值分析，只输出一个分析结果
    - min,max,avg,sum
    - cardinality
  - 多值分析，输出多个分析结果
    - stats,extended stats  //返回一系列数值类型的统计值
    - percentile,percentile rank  //百分位数统计
    - top hits //取排在结果里面的文档

单值分析案例：

~~~
1.min
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "min_age": {
            "min": {
                "field": "age"
            }
        }
    }
}

2.max
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "max_age": {
            "max": {
                "field": "age"
            }
        }
    }
}

3.avg
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "avg_age": {
            "avg": {
                "field": "age"
            }
        }
    }
}

4.sum
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "sum_age": {
            "sum": {
                "field": "age"
            }
        }
    }
}

5.cardinality：意为集合的势，或者基数，是指不同数值的个数，类似SQL中的distinct count概念
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "count_of_job": {
            "cardinality": {
                "field": "job.keyword"
            }
        }
    }
}

~~~

多值分析案例：

~~~
1.stats:返回一系列数值类型的统计值，包含min,max,avg,sum和count
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "stats_age": {
            "stats": {
                "field": "age"
            }
        }
    }
}

2.Extended stats:对stats的扩展，包含了更多的统计数据，如方差，标准差等
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "stats_age": {
            "extended_stats": {
                "field": "age"
            }
        }
    }
}

3.Percentile:百分位数统计
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "per_salary": {
            "percentile": {
                "field": "salary"
            }
        }
    }
}

4.Percentile Rank:百分位数排名
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "per_salary": {
            "percentile_ranks": {
                "field": "salary",
                "values": [ //数值
                    11000,
                    30000
                ]
            }
        }
    }
}

GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "per_salary": {
            "percentile_ranks": {
                "field": "salary",
                "percents": [ //百分位
                    95,
                    99,
                    99.9
                ]
            }
        }
    }
}

5.Top Hits:一般用于分桶后获取该桶内最匹配的顶部文档列表，即详情数据
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "jobs": {
            "terms": {
                "field": "job.keyword",
                "size": 10
            },
			"aggs": { //子聚合
				"top_emp": {
                    "top_hits": {
                        "size": 10,
                        "sort": [
                            { "age": { "order": "desc" } }
                        ]
                    }
                 }   
        	}            
        }        
    }
}

~~~

### 8.2.Bucket聚合分析

Bucket，意为桶，即按照一定的规则将文档分配到不同的桶中，达到分类分析的目的

~~~
1.直接使用term来分桶，如果是text类型，则按照分词后的结果分桶
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "jobs": {
            "terms": {
                "field": "job.keyword",
                "size": 5
            }
        }
    }
}

2.Range:通过指定数值的范围来设定分桶规则
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "salary_range": {
            "range": {
                "field": "salary",
                "ranges": [
                    { "to": 10000 },
                    { "from": 10000, "to": 20000 },
                    { "from": 20000 }
                ]
            }
        }
    }
}

3.Date Range:通过指定日期的范围来设定分桶规则
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "date_range": {
            "range": {
                "field": "birth",
                "format": "yyyy",
                "ranges": [
                    { "from": "1980", "to": "1990" },
                    { "from": "1990", "to": "2000" },
                    { "from": "2000" }
                ]
            }
        }
    }
}

4.Historgram:直方图，以固定间隔的策略来分割数据
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "salary_hist": {
            "histogram": {
                "field": "salary",
                "interval": 5000, //指定5000一个间隔
                "extended_bounds": { //指定数据范围
                    "min": 0,
                    "max": 40000
                }
            }
        }
    }
}

5.Date Historgram:针对日期的直方图或柱状图，是时序数据分析中常用的聚合分析类型
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "by_year": {
            "date_historgram": {
                "field": "birth",
                "interval": "year", //间隔大小
                "format": "yyyy"
            }
        }
    }
}
~~~

### 8.3.Bucket + Metric

- Bucket聚合分析允许通过添加子分析来进一步进行分析，该分析可以是Bucket也可以是Metric。这也使的es的聚合分析能力变的异常强大

案例：

~~~
1.分桶后在分桶
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "jobs": {
            "terms": {
                "field": "job.keyword",
                "size": 10
            },
            "aggs": {
                "age_range": {
                    "range": {
                        "field": "age",
                        "range": [
                            { "to": 20 },
                            { "from": 20, "to": 30 },
                            { "from": 30 }
                        ]
                    }
                }
            }
        }
    }
}

2.分桶后进行指标分析
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "jobs": {
            "terms": {
                "field": "job.keyword",
                "size": 10
            }
        },
        "aggs": {
            "salary": {
                "stats": {
                    "field": "salary"
                }
            }
        }
    }
}
~~~

### 8.4.Pipeline聚合分析

- 针对聚合分析的结果再次进行聚合分析，而且支持链式调用，可以回答如下问题：
  - 订单月平均销售额是多少

- Pipeline的分析结果会输出到原结果中，根据输出位置不同，分为以下两类：
  - Parent：结果内嵌到现有的聚合分析结果中
    - Derivative：求倒
    - Moving Average：移动平均
    - Cumulative Sum：累计求和
  - Sibling：结果与现有聚合分析结果同级
    - Max/Minx/Avg/Sum Bucket
    - Stats/Extended Stats Bucket
    - Percentiles Bucket：

~~~
1.订单月平均销售额是多少
POST /my_index/_search
{
    "size": 0,
    "aggs": {
        "sales_per_mouth": {
            "date_histogram": {
                "filed": "date",
                "interval": "mouth"
            },
            "aggs": {
                "sales": {
                    "sum": {
                        "filed": "price"
                    }
                }
            }            
        },
        "avg_monthly_sales": {
            "avg_bucket": {
                "bucket_path": "sales_per_mouth > sales"
            }
        }        
    }
}

2.找出所有Bucket中值最小的Bucket名称和值
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "jobs": {
            "terms": {
                "field": "job.keyword",
                "size": 10
            },
            "aggs": {
                "avg_salary": {
                    "avg": {
                        "field": "salary"
                    }
                }
            }            
        },
        "min_salary_by_job": {
            "min_bucket": {
                "buckets_path": "jobs>avg_salary"
            }
        }
    }
}

3.计算Bucket值的导数
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "birth": {
            "date_histogram": {
                "field": "birth",
                "interval": "year",
                "min_doc_count": 0
            },
            "aggs": {
                "avg_salary": {
                    "avg": {
                        "field": "salary"
                    }
                },
                "derivative_avg_salary": {
                    "derivative": { //求导关键字
                        "buckets_path": "avg_salary"
                    }
                }                
            }
        }
    }
}
~~~

### 8.5.作用范围

- es聚合分析默认作用范围是query的结果集，可以通过如下的方式改变其作用范围：
  - filter：为某个聚合分析设定过滤条件，从而在不更改整体query语句的情况下修改了作用范围
  - post_filter：作用于文档过滤，但在聚合分析后生效
  - global：无视query过滤条件，基于全部文档进行分析

~~~
1.filter
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "jobs_salary_small": {
            "filter": { //过滤条件
                "range": {
                    "salary": {
                        "to": 10000
                    }
                }
            },
            "aggs": {
                "jobs": {
                    "terms": {
                        "field": "job.keyword"
                    }
                }
            }
        },
        "jobs": {
            "terms": {
                "field": "job.keyword"
            }
        }
    }
}

2.post_filter
GET /my_index/_search
{
    "aggs": {
        "jobs": {
            "terms": {
                "field": "job.keyword"
            }
        }
    },
    "post_filter": {
        "match": {
            "job.keyword": "java engineer"
        }
    }
}

3.global
GET /my_index/_search
{
    "query": {
        "match": {
            "job.keyword": "java engineer"
        }
    },
    "aggs": {
        "java_avg_salary": {
            "avg": {
                "field": "salary"
            }
        },
        "all": {
            "global": {},
            "aggs": {
                "avg_salary": {
                    "avg": {
                        "field": "salary"
                    }
                }
            }
        }
    }
}
~~~

### 8.6.排序

- 可以使用自带的关键数据进行排序，比如：
  - _count文档数
  - _key按照key值排序

~~~
1.根据字段信息排序
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "jobs": {
            "terms": {
                "field": "job.keyword",
                "size": 10,
                "order": [
                    { "_count": "asc" },
                    { "_key": "desc" }
                ]
            }
        }
    }
}

2.根据子聚合信息排序
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "jobs": {
            "terms": {
                "field": "job.keyword",
                "size": 10,
                "order": [
                    { "avg_salary": "desc" }
                ]
            },
            "aggs": {
                "avg_salary": {
                    "avg": { "field": "salary" }
                }
            }
        }
    }
}

3.根据子聚合连级排序
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "jobs": {
            "terms": {
                "field": "job.keyword",
                "size": 10,
                "order": [
                    { "stats_salary.sum": "desc" }
                ]
            },
            "aggs": {
                "stats_salary": {
                    "stats": { "field": "salary" }
                }
            }
        }
    }
}

4.根据子聚合多级排序
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "salary_hits": {
            "histogram": {
                "field": "salary",
                "interval": 5000,
                "order": { "age>avg_age": "desc" }
            },
            "aggs": {
                "age": {
                    "filter": {
                        "range": {
                            "age": { "gte": 10 }
                        }
                    },
                    "aggs": {
                        "avg_age": {
                            "avg": { "field": "age" }
                        }
                    }
                }
            }
        }
    }
}
~~~

### 8.7.查询原理和精准度问题

- Terms聚合不准确的解决办法
  - 设置shard数为1，消除数据分散的问题，但无法承载大数据量
  - 合理设置Shard_Size大小，即每次从Shard上额外多获取数据，以提升准确度
    - shard_size默认大小如下：shard_size=(size*1.5)+10
    - 通过调整shard_size的大小降低doc_count_error_upper_bound来提升准确度
    - 增大了整体的计算量，从而降低了响应时间

~~~
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "jobs": {
            "terms": {
                "field": "job.keyword",
                "size": 1,
                "shard_size": 10
            }
        }
    }
}

注：
shard_size大小设定方式：
term聚合返回结果中有如下两个统计值：
doc_count_error_upper_bound:被遗漏的term可能的最大值
sum_other_doc_count:返回结果bucket的term外其他term的文档总数

2.在聚合分析中设定show_term_doc_count_error，会在返回结果中包含doc_count_error_upper_bound=0则表示计算准确
GET /my_index/_search
{
    "size": 0,
    "aggs": {
        "jobs": {
            "terms": {
                "field": "job.keyword",
                "size": 2,
                "show_term_doc_count_error": true
            }
        }
    }
}
~~~

### 8.8.近似统计算法

- 在Es的聚合分析中，Cardinality和Percentile分析使用的是近似统计算法
  - 结果近似准确，但不一定精确
  - 可以通过参数的调整使其结果精确，但同时也意味着更多的计算时间和更大性功能消耗

~~~

~~~





## 9.数据建模相关

- ES Index Template
- ES Index Mapping配置
  - 字段配置
  - 索引关系处理

### 9.1.Mapping字段的相关设置

- enbaled
  - true(默认)|false
  - 仅存储，不做搜索或聚合分析
- index
  - true|false
  - 是否构建倒排索引
- index_options
  - docs|freqs|positions|offsets
  - 存储倒排索引的那些信息
- norms
  - true|false
  - 是否存储归一化相关的参数，如果字段仅用于过滤和聚合分析，可关闭
- doc_values
  - true|false
  - 是否启用doc_values，用于排序和聚合分析
- field_data
  - false|true
  - 是否为text类型启动fielddata，实现排序和聚合分析
- store
  - false|true
  - 是否存储该字段值
- coerce
  - true|false
  - 是否开启自动数据类型转换，比如字符串转为数字，浮点转为整形
- multifields多字段
  - 灵活使用多字段特性来解决多样的业务需求
- dynamic
  - true|false|strict
  - 控制mapping自动更新
- date_detection
  - true|false
  - 是否自动识别日期类型

### 9.2. 数据类型选择

- 字符串类型
  - 需要分词则设定为text类型，否则设置为keyword类型
- 枚举类型
  - 基于性能考虑将其设定为keyword类型，即便该数据为整型
- 数值类型
  - 尽量选择贴近的类型，比如byte即可表示所有数值时，即选择byte，不要用long
- 其他类型
  - 比如布尔类型，日期，地理位置数据等

### 9.3.检索选择

- 完全不需要检索，排序，聚合分析的字段
  - enabled设置为false
- 不需要检索的字段
  - index设置为false
- 需要检索的字段，可以通过如下配置设定需要的存储粒度
  - index_options结合需要设定
  - norms不需要归一化数据时关闭即可
- 不需要排序或者聚合分析功能
  - doc_values设定为false
  - flelddata设定为false
- 是否需要专门存储当前字段的数据
  - store设定为true，即可存储该字段的原始内容(与_source中的不相关)
  - 一般结合_source的enable设定为false时使用

### 9.4.案例分析

~~~json
1.创建一个blog_mapping，返回_source数据
PUT blog_index 
{
  "mappings": {
    "doc": {
      "properties": {
        "title": {
          "type": "text",
          "fields": {
            "keyword": {
              "type": "keyword"
            }
          }
        },
        "publish_date": {
          "type": "date"
        },
        "author": {
          "type": "keyword"
        },
        "abstract": {
          "type": "text"
        },
        "url": {
          "enabled":false
        },
        "content": {
          "type": "text"
        }
      }
    }
  }
}

查询
GET blog_index/_search?_source=title

结果
{
  "took": 19,
  "timed_out": false,
  "_shards": {
    "total": 5,
    "successful": 5,
    "skipped": 0,
    "failed": 0
  },
  "hits": {
    "total": 1,
    "max_score": 1,
    "hits": [
      {
        "_index": "blog_index",
        "_type": "doc",
        "_id": "1",
        "_score": 1,
        "_source": {
          "title": "blog title"
        }
      }
    ]
  }
}

注意：虽然可以通过指定_source来控制返回字段，但是es的运行机制是会将_source中的内容全部返回。只是在显示的时候过滤。这样影响性能

---------------------------------------------------------------------------------
2.store的使用，结合_source的enable设定为false返回数据
PUT blog_index 
{
  "mappings": {
    "doc": {
      "_source": {
        "enabled": false
      },
      "properties": {
        "title": {
          "type": "text",
          "fields": {
            "keyword": {
              "type": "keyword"
            }
          },
          "store": true
        },
        "publish_date": {
          "type": "date",
          "store": true
        },
        "author": {
          "type": "keyword",
          "store": true
        },
        "abstract": {
          "type": "text",
          "store": true
        },
        "url": {
          "type": "keyword",
          "doc_values": false,
          "norms": false, 
          "store": true, 
          "ignore_above": 100
        },
        "content": {
          "type": "text",
          "store": true
        }
      }
    }
  }
}

3.查询
GET /blog_index/_search
{
  "stored_fields": ["title"],
  "query": {
    "match_all": {}
  }
}

4.返回结果
{
  "took": 6,
  "timed_out": false,
  "_shards": {
    "total": 5,
    "successful": 5,
    "skipped": 0,
    "failed": 0
  },
  "hits": {
    "total": 1,
    "max_score": 1,
    "hits": [
      {
        "_index": "blog_index",
        "_type": "doc",
        "_id": "1",
        "_score": 1,
        "fields": {
          "title": [
            "blog title"
          ],
          "content": [
            "blog content"
          ]
        }
      }
    ]
  }
}

~~~

### 9.5.处理关联关系

在ES中可以通过如下两种手段变相解决

#### 9.5.1Nested Object



#### 9.5.2.Parent/Child

案例分析

~~~json
PUT blog_index_parent_child
{
  "mappings": {
    "doc": {
      "properties": {
        "join": {
          "type": "join", //指明类型
          "relations": { //指明父子关系
            "blog":"comment" // blog为父类型名称,comment子类型名称
          }
        }
      }
    }
  }
}
注意：6.0版本后才有join类型

创建文档
PUT blog_index_parent_child/doc/1
{
    "title":"blog",
    "join":"blog" //指明父类型
}

创建子文档
PUT blog_index_parent_child/doc/comment-1?routing=1
{
	"comment":"comment world",
	"join": {
        "name":"comment", //指明子类型
        "parent":1 //指明父文档Id
	}
}
注意：指明routing值，确保父子文档在一个分片上，一般使用父文档id
~~~

常见query语法包括如下几种：

- parent_id返回某父文档的子文档
- has_child返回包含某子文档的父文档
- has_parent返回包含父文档的子文档

~~~
1.根据父文档id查询子文档
GET blog_index_parent_child/_search
{
    "query": {
        "parent_id": { //关键字
            "type": "comment", //制定子文档类型
            "id": 2 //指明父文档id
        }
    }
}

2.根据子文档中包含的信息返回父文档
GET blog_index_parent_child/_search
{
    "query": {
        "has_child": { //关键字
            "type": "comment", //指定子文档类型
            "query": { //指明子文档的查询条件
                "match": {
                    "comment": "world"
                }
            }
        }
    }
}

3.根据父文档中包含的信息返回子文档
GET blog_index_parent_child/_search
{
    "query": {
        "has_parent": {
            "parent_type": "blog",
            "query": {
                "match": {
                    "title": "blog"
                }
            }
        }
    }
}
~~~

### 9.6.Reindex

- 指重建所有数据的过程，一般发生在如下情况：
  - mapping设置变更，比如字段类型变化，分词器字典更新等
  - index设置变更，比如分片数更改等
  - 迁移数据
- ES提供了现场的API用于完成该工作
  - _update_by_query在现有索引上重建
  - _reindex在其他索引上重建

~~~json
1.将blog_index的所有文档重建一遍
POST blog_index/_update_by_query?conflicts=proceed
注：conflicts=proceed表示如果遇到版本冲突，覆盖并继续执行

2.更新blog_index索引的部分字段和文档
POST blog_index/_update_by_query
{
    "script": { //更新文档的字段值
        "source": "ctx.source.likes++",
        "lang": "painless"
    },
    "query": { //可以更新部分文档
        "term": {
            "user": "tom"
        }
    }
}

3.将source的数据重建到dest中
POST _reindex?wait_for_completion=false
{
	"conflicts": "proceed", //冲突时覆盖并继续
    "source": { //旧索引位置
        "index":"blog_index",
        "remote" : {
          "host": "http://192.168.0.11:9200"  
        },
        "query": {
            "term": {
                "user": "tom"
            }
        },
        "size": 5000
    },
    "dest": { //新索引位置
        "index": "blog_new_index",
        "version_type": "internal"
    }
}

reindex性能优化：https://yq.aliyun.com/articles/635243
reindex官方API文档:https://www.elastic.co/guide/en/elasticsearch/reference/6.4/docs-reindex.html

version_type : 

~~~

- 数据重建的时间受源索引文档规模的影响，当规模越大时，所需时间越多，此时需要通过设定url参数wait_for_completion为false来异步执行，ES以task来描述此类执行任务
- ES提供了Task API来查看任务的执行进度和相关数据
- 通过 Get _task/daddxxxx111 来查看任务执行情况

~~~
Get _task/daddxxxx111
~~~

### 9.7.悲观锁并发控制

1.全局锁

~~~
PUT /fs/lock/global/_create
{}
fs:你要上锁的那个index
lock:就是你指定的一个对这个index上全局锁的type
global:就是你上的全局锁的对应文档的id
_create：强制必须是创建，如果/fs/lock/global这个doc已经存在，那么创建失败，报错
~~~

2.document锁(相当于行及锁)

~~~

~~~



## 10.集群调优

